import json
import os
import random
import string
import hashlib
import tkinter as tk
from tkinter import messagebox, simpledialog

# Ai was used to create the viewbox / design 
class PasswordManager:
    def __init__(self):
        # Get the directory where this script is located
        script_dir = os.path.dirname(os.path.abspath(__file__))
        self.data_file = os.path.join(script_dir, "passwords.json")
        self.master_file = os.path.join(script_dir, "master.json")
        self.entries = {}
        self.master_password = ""
        self.logged_in = False
        
    def _encrypt(self, text, key):
        """Simple XOR encryption"""
        key_hash = hashlib.md5(key.encode()).hexdigest()
        encrypted = ""
        for i, char in enumerate(text):
            encrypted += chr(ord(char) ^ ord(key_hash[i % len(key_hash)]))
        return encrypted.encode().hex()
    
    def _decrypt(self, encrypted_hex, key):
        """Simple XOR decryption"""
        key_hash = hashlib.md5(key.encode()).hexdigest()
        encrypted = bytes.fromhex(encrypted_hex).decode()
        decrypted = ""
        for i, char in enumerate(encrypted):
            decrypted += chr(ord(char) ^ ord(key_hash[i % len(key_hash)]))
        return decrypted
    
    def _hash(self, password):
        return hashlib.sha256(password.encode()).hexdigest()
    
    def _generate_password(self, length=16):
        chars = string.ascii_letters + string.digits + "!@#$%"
        return ''.join(random.choice(chars) for _ in range(length))
    
    def setup_master(self, username, password):
        # Check if file exists and is valid
        if os.path.exists(self.master_file):
            try:
                with open(self.master_file, 'r') as f:
                    data = json.load(f)
                    # If file exists and has valid data, credentials already exist
                    if data.get("username") and data.get("password_hash"):
                        return False, "Master credentials already exist"
            except (json.JSONDecodeError, IOError):
                # File exists but is corrupted or empty, allow overwrite
                pass
        
        if not username or not password:
            return False, "Username and password cannot be empty"
        
        with open(self.master_file, 'w') as f:
            json.dump({
                "username": username,
                "password_hash": self._hash(password)
            }, f)
        return True, "Master credentials saved"
    
    def login(self, username, password):
        if not os.path.exists(self.master_file):
            return False, "No master credentials found"
        
        with open(self.master_file, 'r') as f:
            master = json.load(f)
        
        if username != master["username"] or self._hash(password) != master["password_hash"]:
            return False, "Invalid username or password"
        
        self.master_password = password
        self.logged_in = True
        return True, "Login successful"
    
    def _load(self):
        if not os.path.exists(self.data_file):
            self.entries = {}
            return
        
        with open(self.data_file, 'r') as f:
            data = json.load(f)
        
        self.entries = {}
        for domain, entry in data.items():
            self.entries[domain] = {
                "username": entry["username"],
                "password": self._decrypt(entry["encrypted_password"], self.master_password)
            }
    
    def _save(self):
        data = {}
        for domain, entry in self.entries.items():
            data[domain] = {
                "username": entry["username"],
                "encrypted_password": self._encrypt(entry["password"], self.master_password)
            }
        
        with open(self.data_file, 'w') as f:
            json.dump(data, f)
    
    def find_password(self, domain):
        self._load()
        if domain in self.entries:
            return True, self.entries[domain]
        return False, None
    
    def add_password(self, domain, username, password):
        self._load()
        if domain in self.entries:
            return False, "Entry already exists"
        
        self.entries[domain] = {"username": username, "password": password}
        self._save()
        return True, "Password added"
    
    def change_password(self, domain, password):
        self._load()
        if domain not in self.entries:
            return False, "Entry not found"
        
        self.entries[domain]["password"] = password
        self._save()
        return True, "Password changed"
    
    def reset_all_data(self, include_master=False):
        """Reset all saved data. If include_master is True, also deletes master credentials."""
        try:
            # Delete passwords file
            if os.path.exists(self.data_file):
                os.remove(self.data_file)
            
            # Optionally delete master credentials
            if include_master and os.path.exists(self.master_file):
                os.remove(self.master_file)
            
            # Clear in-memory data
            self.entries = {}
            
            return True, "All data reset successfully"
        except Exception as e:
            return False, f"Error resetting data: {e}"


class App:
    def __init__(self, root):
        self.root = root
        self.root.title("Password Manager")
        self.root.geometry("400x300")
        
        self.manager = PasswordManager()
        self.show_login()
    
    def clear_window(self):
        for widget in self.root.winfo_children():
            widget.destroy()
    
    def show_login(self):
        self.clear_window()
        
        tk.Label(self.root, text="Password Manager", font=("Arial", 16)).pack(pady=20)
        
        tk.Label(self.root, text="Username:").pack()
        self.username_entry = tk.Entry(self.root, width=30)
        self.username_entry.pack(pady=5)
        
        tk.Label(self.root, text="Password:").pack()
        self.password_entry = tk.Entry(self.root, width=30, show="*")
        self.password_entry.pack(pady=5)
        
        tk.Button(self.root, text="Login", command=self.do_login, width=20).pack(pady=10)
        tk.Button(self.root, text="Setup (First Time)", command=self.show_setup, width=20).pack()
    
    def show_setup(self):
        self.clear_window()
        
        tk.Label(self.root, text="Setup Master Credentials", font=("Arial", 14)).pack(pady=20)
        
        # Check if file exists and offer to reset
        if os.path.exists(self.manager.master_file):
            response = messagebox.askyesno("Reset Credentials", 
                "Master credentials file exists. Do you want to reset and create new credentials?")
            if response:
                try:
                    os.remove(self.manager.master_file)
                    messagebox.showinfo("Reset", "Old credentials deleted. You can now create new ones.")
                except Exception as e:
                    messagebox.showerror("Error", f"Could not delete old credentials: {e}")
                    self.show_login()
                    return
            else:
                self.show_login()
                return
        
        tk.Label(self.root, text="Username:").pack()
        username_entry = tk.Entry(self.root, width=30)
        username_entry.pack(pady=5)
        
        tk.Label(self.root, text="Password:").pack()
        password_entry = tk.Entry(self.root, width=30, show="*")
        password_entry.pack(pady=5)
        
        def setup():
            username = username_entry.get()
            password = password_entry.get()
            success, msg = self.manager.setup_master(username, password)
            messagebox.showinfo("Setup", msg)
            if success:
                self.show_login()
        
        tk.Button(self.root, text="Save", command=setup, width=20).pack(pady=10)
        tk.Button(self.root, text="Back", command=self.show_login, width=20).pack()
    
    def do_login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        success, msg = self.manager.login(username, password)
        messagebox.showinfo("Login", msg)
        if success:
            self.show_main()
    
    def show_main(self):
        self.clear_window()
        
        tk.Label(self.root, text="Password Manager", font=("Arial", 16)).pack(pady=10)
        
        tk.Button(self.root, text="Find Password", command=self.find_password, width=25).pack(pady=5)
        tk.Button(self.root, text="Add Password", command=self.add_password, width=25).pack(pady=5)
        tk.Button(self.root, text="Change Password", command=self.change_password, width=25).pack(pady=5)
        tk.Button(self.root, text="Reset All Data", command=self.reset_all_data, width=25).pack(pady=5)
        tk.Button(self.root, text="Logout", command=self.show_login, width=25).pack(pady=10)
    
    def find_password(self):
        domain = simpledialog.askstring("Find Password", "Enter domain/application name:")
        if domain:
            success, result = self.manager.find_password(domain)
            if success:
                msg = f"Domain: {domain}\nUsername: {result['username']}\nPassword: {result['password']}"
                messagebox.showinfo("Password Found", msg)
            else:
                messagebox.showwarning("Not Found", f"No entry found for '{domain}'")
    
    def add_password(self):
        domain = simpledialog.askstring("Add Password", "Enter domain/application name:")
        if not domain:
            return
        
        username = simpledialog.askstring("Add Password", "Enter username:")
        if not username:
            return
        
        choice = messagebox.askyesno("Password", "Generate random password?")
        if choice:
            password = self.manager._generate_password()
            messagebox.showinfo("Generated Password", f"Your password: {password}")
        else:
            password = simpledialog.askstring("Add Password", "Enter password:", show="*")
            if not password:
                return
        
        success, msg = self.manager.add_password(domain, username, password)
        messagebox.showinfo("Add Password", msg)
    
    def change_password(self):
        domain = simpledialog.askstring("Change Password", "Enter domain/application name:")
        if not domain:
            return
        
        choice = messagebox.askyesno("Password", "Generate random password?")
        if choice:
            password = self.manager._generate_password()
            messagebox.showinfo("Generated Password", f"Your password: {password}")
        else:
            password = simpledialog.askstring("Change Password", "Enter new password:", show="*")
            if not password:
                return
        
        success, msg = self.manager.change_password(domain, password)
        messagebox.showinfo("Change Password", msg)
    
    def reset_all_data(self):
        # Ask for confirmation
        response = messagebox.askyesno("Reset All Data", 
            "This will delete ALL saved passwords. This action cannot be undone!\n\nDo you want to continue?")
        if not response:
            return
        
        # Ask if they also want to reset master credentials
        reset_master = messagebox.askyesno("Reset Master Credentials", 
            "Do you also want to delete master credentials?\n\n(If yes, you'll need to set up new credentials)")
        
        success, msg = self.manager.reset_all_data(include_master=reset_master)
        messagebox.showinfo("Reset Data", msg)
        
        if reset_master:
            # If master credentials were deleted, go back to login
            self.manager.logged_in = False
            self.show_login()


if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
